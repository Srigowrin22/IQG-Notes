package training.iqgateway.view.backing;

import javax.faces.component.html.HtmlForm;
import javax.faces.component.html.HtmlOutputLabel;

public class Error {
    private HtmlForm form1;
    private HtmlOutputLabel outputLabel1;

    public void setForm1(HtmlForm form1) {
        this.form1 = form1;
    }

    public HtmlForm getForm1() {
        return form1;
    }

    public void setOutputLabel1(HtmlOutputLabel outputLabel1) {
        this.outputLabel1 = outputLabel1;
    }

    public HtmlOutputLabel getOutputLabel1() {
        return outputLabel1;
    }
}
