package training.iqgateway.view.backing;

import javax.faces.component.html.HtmlForm;

public class GenerateReports {
    private HtmlForm form1;

    public void setForm1(HtmlForm form1) {
        this.form1 = form1;
    }

    public HtmlForm getForm1() {
        return form1;
    }
}
