package training.iqgateway.ui;

import java.awt.Dimension;

import java.awt.Font;
import java.awt.Rectangle;

import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import training.iqgateway.dao.RoleDAO;
import training.iqgateway.entities.AdminEO;
import training.iqgateway.entities.RoleEO;
import training.iqgateway.factory.GenericDAOFactory;
import training.iqgateway.operations.impl.AdminOperationImpl;

public class RemoveAdminUI extends JFrame {
    private JButton search = new JButton();
    private JLabel jLabel1 = new JLabel();
    private JTextField desigID = new JTextField();
    private JButton delete = new JButton();
    private JTextArea adminTextArea = new JTextArea();
    
     private static RoleDAO roleDAORef = GenericDAOFactory.createRoleDAO();


    public RemoveAdminUI() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(547, 382));
        this.setTitle("REMOVE ADMIN");
        search.setText("SEARCH");
        search.setBounds(new Rectangle(355, 45, 95, 30));
        search.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jLabel1.setText("Designation ID:");
        jLabel1.setBounds(new Rectangle(75, 50, 135, 30));
        jLabel1.setFont(new Font("Tahoma", 0, 18));
        desigID.setBounds(new Rectangle(215, 50, 120, 25));
        delete.setText("DELETE");
        delete.setBounds(new Rectangle(220, 270, 115, 35));
        delete.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    delete_actionPerformed(e);
                }
            });
        adminTextArea.setBounds(new Rectangle(140, 105, 270, 145));
        adminTextArea.setFont(new Font("Tahoma", 1, 11));
        adminTextArea.setBackground(new java.awt.Color(237, 237, 237));
        this.getContentPane().add(adminTextArea, null);
        this.getContentPane().add(delete, null);
        this.getContentPane().add(desigID, null);
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(search, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        String id = desigID.getText();

        AdminOperationImpl adminOpImpl = new AdminOperationImpl();
        AdminEO adminEO = new AdminEO();
        adminEO = adminOpImpl.findAdminByDesigID(id);
        
        RoleEO role = new RoleEO();
        role = roleDAORef.findRoleByRoleID(adminEO.getRoleID().getRoleID());
        String roleName = role.getRoleName();

        if (id != null && adminOpImpl.findAdminByDesigID(id) != null) {
            String adminDetails = "Name: " + adminEO.getName() + "\n" +
                "\nAadhar: " + adminEO.getAadhar() + "\n" +
                "\nRole ID: " + roleName + "\n" +
                "\nDesignation ID: " + adminEO.getDesignationID() + "\n" +
                "\nHire Date: " + adminEO.getHireDate();
            adminTextArea.setText(adminDetails);
            adminTextArea.setEditable(false);
        } else {
            clearFields();
            JOptionPane.showMessageDialog(this, "Invalid ID", "Error",
                                          JOptionPane.ERROR_MESSAGE);
            System.out.println("Failed to fetch!");
        }
    }

    private void delete_actionPerformed(ActionEvent e) {
        String id = desigID.getText();

        AdminOperationImpl adminOpImpl = new AdminOperationImpl();
        AdminEO adminEO = new AdminEO();
        adminEO = adminOpImpl.findAdminByDesigID(id);

        if (id != null && adminOpImpl.removeAdmin(adminEO) != null) {
            JOptionPane.showMessageDialog(this,
                                          "Designation ID " + id + " deleted successfully.",
                                          "Deleted",
                                          JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        } else {
            clearFields();
            JOptionPane.showMessageDialog(this, "Invalid ID", "Error",
                                          JOptionPane.ERROR_MESSAGE);
            System.out.println("Failed to Delete!");
        }
    }

    private void clearFields() {
        adminTextArea.setText("");
        desigID.setText("");
    }
}
