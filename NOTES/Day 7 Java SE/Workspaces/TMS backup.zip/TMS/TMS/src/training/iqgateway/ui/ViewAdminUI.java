package training.iqgateway.ui;

import java.awt.Color;
import java.awt.Dimension;

import java.awt.Font;
import java.awt.Rectangle;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.List;

import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import training.iqgateway.dao.RoleDAO;
import training.iqgateway.entities.AdminEO;
import training.iqgateway.entities.RoleEO;
import training.iqgateway.factory.GenericDAOFactory;
import training.iqgateway.operations.impl.AdminOperationImpl;

public class ViewAdminUI extends JFrame {

    private static RoleDAO roleDAORef = GenericDAOFactory.createRoleDAO();
    private JScrollPane scroll = new JScrollPane();
    private JTable table = new JTable();


    public ViewAdminUI() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(612, 405));
        this.setTitle("VIEW ALL ADMINS");
        table.setBounds(new Rectangle(15, 15, 555, 320));
        viewAdminList();
    }

    private void viewAdminList() {
        AdminOperationImpl adminOpImpl = new AdminOperationImpl();
        List<AdminEO> adminEOList = new ArrayList();
        adminEOList = adminOpImpl.listAllAdmin();
        RoleEO role = new RoleEO();

        SimpleDateFormat sdf =
            new SimpleDateFormat("dd-MMM-yy", Locale.ENGLISH);

        String[] columnNames =
        { "ROLE", "DESGNT. ID", "NAME", "AADHAR", "HIRE DATE" };

        Object[][] data = new Object[adminEOList.size()][columnNames.length];

        for (int i = 0; i < adminEOList.size(); i++) {
            AdminEO adminEO = adminEOList.get(i);
            role = roleDAORef.findRoleByRoleID(adminEO.getRoleID().getRoleID());
            String roleName = role.getRoleName();
            data[i][0] = roleName;
            data[i][1] = adminEO.getDesignationID();
            data[i][2] = adminEO.getName();
            data[i][3] = adminEO.getAadhar();
            data[i][4] = (adminEO.getHireDate() != null) ? sdf.format(adminEO.getHireDate()) : "";
        }

        table = new JTable(data, columnNames);
        table.setBackground(new Color(237, 237, 237));
        table.setFont(new Font("Tahoma", Font.BOLD, 12));
        table.setRowHeight(22);

        scroll = new JScrollPane(table);
        scroll.setBounds(new Rectangle(20, 20, 540, 305));
        this.getContentPane().add(scroll, null);

    }
}
