package training.iqgateway.ui;

import java.awt.Dimension;

import java.awt.Font;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Locale;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import training.iqgateway.dao.RoleDAO;
import training.iqgateway.entities.AdminEO;
import training.iqgateway.entities.RoleEO;
import training.iqgateway.factory.GenericDAOFactory;
import training.iqgateway.operations.impl.AdminOperationImpl;

public class ModifyAdminUI extends JFrame {
    private JButton update = new JButton();
    private JTextField Dates = new JTextField();
    private JTextField Aadhar = new JTextField();
    private JTextField Name = new JTextField();
    private JTextField DesigID = new JTextField();
    private JTextField RoleName = new JTextField();
    private JLabel roleID4 = new JLabel();
    private JLabel roleID3 = new JLabel();
    private JLabel roleID2 = new JLabel();
    private JLabel roleID1 = new JLabel();
    private JLabel roleName = new JLabel();
    private JTextField desigIDFld = new JTextField();
    private JLabel jLabel1 = new JLabel();
    private JButton search = new JButton();

    private static RoleDAO roleDAORef = GenericDAOFactory.createRoleDAO();


    public ModifyAdminUI() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(553, 458));
        this.setTitle("MODIFY ADMIN");
        update.setText("UPDATE");
        update.setBounds(new Rectangle(195, 355, 100, 35));
        update.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    UpdateButton_actionPerformed(e);
                }
            });
        Dates.setBounds(new Rectangle(275, 295, 200, 30));
        Aadhar.setBounds(new Rectangle(275, 245, 200, 30));
        Name.setBounds(new Rectangle(275, 195, 200, 30));
        DesigID.setBounds(new Rectangle(275, 145, 200, 30));
        RoleName.setBounds(new Rectangle(275, 100, 200, 30));
        roleID4.setText("Hire Date:");
        roleID4.setBounds(new Rectangle(55, 305, 115, 25));
        roleID4.setFont(new Font("Tahoma", 0, 18));
        roleID3.setText("Aadhar:");
        roleID3.setBounds(new Rectangle(55, 255, 115, 25));
        roleID3.setFont(new Font("Tahoma", 0, 18));
        roleID2.setText("Name:");
        roleID2.setBounds(new Rectangle(55, 205, 115, 25));
        roleID2.setFont(new Font("Tahoma", 0, 18));
        roleID1.setText("Designation ID:");
        roleID1.setBounds(new Rectangle(55, 155, 160, 25));
        roleID1.setFont(new Font("Tahoma", 0, 18));
        roleName.setText("Role Name:");
        roleName.setBounds(new Rectangle(55, 105, 115, 25));
        roleName.setFont(new Font("Tahoma", 0, 18));
        desigIDFld.setBounds(new Rectangle(195, 40, 120, 25));
        jLabel1.setText("Designation ID:");
        jLabel1.setBounds(new Rectangle(55, 40, 135, 30));
        jLabel1.setFont(new Font("Tahoma", 0, 18));
        search.setText("SEARCH");
        search.setBounds(new Rectangle(335, 35, 95, 35));
        search.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    search_actionPerformed(e);
                }
            });
        this.getContentPane().add(search, null);
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(desigIDFld, null);
        this.getContentPane().add(roleName, null);
        this.getContentPane().add(roleID1, null);
        this.getContentPane().add(roleID2, null);
        this.getContentPane().add(roleID3, null);
        this.getContentPane().add(roleID4, null);
        this.getContentPane().add(RoleName, null);
        this.getContentPane().add(DesigID, null);
        this.getContentPane().add(Name, null);
        this.getContentPane().add(Aadhar, null);
        this.getContentPane().add(Dates, null);
        this.getContentPane().add(update, null);
    }


    private void search_actionPerformed(ActionEvent e) {
        String id = desigIDFld.getText();

        AdminOperationImpl adminOpImpl = new AdminOperationImpl();
        AdminEO adminEO = new AdminEO();
        adminEO = adminOpImpl.findAdminByDesigID(id);

        if (id != null && adminOpImpl.findAdminByDesigID(id) != null) {

            RoleEO role = new RoleEO();
            role = roleDAORef.findRoleByRoleID(adminEO.getRoleID().getRoleID());
            RoleName.setText(role.getRoleName());
            RoleName.setEditable(false);
            DesigID.setText(adminEO.getDesignationID());
            DesigID.setEditable(false);
            Name.setText(adminEO.getName());
            Aadhar.setText(adminEO.getAadhar());
            Aadhar.setEditable(false);
            Dates.setText(adminEO.getHireDate() + "");

        } else {
            clearFields();
            JOptionPane.showMessageDialog(this, "Invalid ID", "Error",
                                          JOptionPane.ERROR_MESSAGE);
            System.out.println("Failed to fetch!");
        }
    }

    private void UpdateButton_actionPerformed(ActionEvent e) {
        String name = Name.getText();
        String dates = Dates.getText();

        AdminOperationImpl adminOpImpl = new AdminOperationImpl();
        AdminEO adminEO = new AdminEO();
        adminEO = adminOpImpl.findAdminByAadhar(Aadhar.getText());
        adminEO.setName(name);
        if (!dates.equals("")) {
            try {
                SimpleDateFormat sdf =
                    new SimpleDateFormat("dd-MMM-yy", Locale.ENGLISH);
                Date utilDate = sdf.parse(dates);
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                adminEO.setHireDate(sqlDate);
            } catch (Exception es) {
                es.printStackTrace();
            }
        } else {
            Date date = new Date(); //TODO
            adminEO.setHireDate(null);
        }

        System.out.println(adminOpImpl.modifyAdmin(adminEO));

        if (adminOpImpl.findAdminByAadhar(Aadhar.getText()) != null) {

            String adminDetails = "Name: " + adminEO.getName() + "\n" +
                "Aadhar: " + adminEO.getAadhar() + "\n" +
                "Role ID: " + adminEO.getRoleID().getRoleID() + "\n" +
                "Designation ID: " + adminEO.getDesignationID() + "\n" +
                "Hire Date: " + adminEO.getHireDate();

            JOptionPane.showMessageDialog(this,
                                          "Admin updated successfully!\t\t\n\n" +
                    adminDetails, "Success", JOptionPane.INFORMATION_MESSAGE);

            clearFields();
        } else {
            JOptionPane.showMessageDialog(this,
                                          "Failed to update admin. Please try again.",
                                          "Warning",
                                          JOptionPane.WARNING_MESSAGE);

            clearFields();
        }
    }
    private void clearFields() {
        desigIDFld.setText("");
        RoleName.setText("");
        DesigID.setText("");
        Name.setText("");
        Aadhar.setText("");
        Dates.setText("");
        desigIDFld.requestFocus();
    }
}
