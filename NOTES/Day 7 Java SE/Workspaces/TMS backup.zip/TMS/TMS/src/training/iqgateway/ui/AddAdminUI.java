package training.iqgateway.ui;


import java.awt.Dimension;

import java.awt.Font;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.util.Date;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import training.iqgateway.entities.AdminEO;
import training.iqgateway.entities.RoleEO;
import training.iqgateway.operations.impl.AdminOperationImpl;
import training.iqgateway.utils.Validation;

public class AddAdminUI extends JFrame {
    private JLabel roleID1 = new JLabel();
    private JLabel roleID2 = new JLabel();
    private JLabel roleID3 = new JLabel();
    private JLabel roleID4 = new JLabel();
    private JTextField Name = new JTextField();
    private JTextField Aadhar = new JTextField();
    private JTextField Dates = new JTextField();
    private JButton AddButton = new JButton();
    private JComboBox newCombo = new JComboBox();
    private JLabel roleID5 = new JLabel();
    private JLabel roleID6 = new JLabel();
    private JLabel roleID8 = new JLabel();
    private JTextField phone = new JTextField();
    private JLabel roleID10 = new JLabel();
    private JComboBox gender = new JComboBox(new String[] { "M", "F", "NA" });
    
    static Validation validate = new Validation();

    public AddAdminUI() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(595, 506));
        this.setTitle("ADD ADMIN");
        roleID1.setText("Designation ID:");
        roleID1.setBounds(new Rectangle(50, 40, 160, 25));
        roleID1.setFont(new Font("Tahoma", 0, 18));
        roleID2.setText("Name:");
        roleID2.setBounds(new Rectangle(55, 120, 115, 25));
        roleID2.setFont(new Font("Tahoma", 0, 18));
        roleID3.setText("Aadhar:");
        roleID3.setBounds(new Rectangle(55, 170, 115, 25));
        roleID3.setFont(new Font("Tahoma", 0, 18));
        roleID4.setText("Hire Date:");
        roleID4.setBounds(new Rectangle(55, 325, 115, 25));
        roleID4.setFont(new Font("Tahoma", 0, 18));
        Name.setBounds(new Rectangle(275, 110, 200, 30));
        Aadhar.setBounds(new Rectangle(275, 160, 200, 30));
        Dates.setBounds(new Rectangle(275, 315, 200, 30));
        AddButton.setText("ADD");
        AddButton.setBounds(new Rectangle(235, 380, 75, 30));
        AddButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    AddButton_actionPerformed(e);
                }
            });
        AdminOperationImpl adminOpImplCombo = new AdminOperationImpl();
        List<RoleEO> roleEOList = adminOpImplCombo.findAllRoles();
        for (RoleEO role : roleEOList) {
            newCombo.addItem(role.getRoleName());
        }
        newCombo.setBounds(new Rectangle(245, 35, 245, 35));
        newCombo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    newCombo_actionPerformed(e);
                }
            });
        roleID5.setText("Aadhar:");
        roleID5.setBounds(new Rectangle(55, 170, 115, 25));
        roleID5.setFont(new Font("Tahoma", 0, 18));
        roleID6.setText("Name:");
        roleID6.setBounds(new Rectangle(55, 120, 115, 25));
        roleID6.setFont(new Font("Tahoma", 0, 18));
        roleID8.setText("Gender:");
        roleID8.setBounds(new Rectangle(55, 270, 115, 25));
        roleID8.setFont(new Font("Tahoma", 0, 18));
        phone.setBounds(new Rectangle(275, 210, 200, 30));
        gender.setBounds(new Rectangle(275, 260, 200, 30));
        gender.setFont(new Font("Tahoma", Font.PLAIN, 16));
        gender.setPreferredSize(new Dimension(120, 32));
        
        roleID10.setText("Phone:");
        roleID10.setBounds(new Rectangle(55, 220, 115, 25));
        roleID10.setFont(new Font("Tahoma", 0, 18));
        this.getContentPane().add(roleID10, null);
        this.getContentPane().add(gender, null);
        this.getContentPane().add(phone, null);
        this.getContentPane().add(roleID8, null);
        this.getContentPane().add(roleID6, null);
        this.getContentPane().add(roleID5, null);
        this.getContentPane().add(newCombo, null);
        this.getContentPane().add(AddButton, null);
        this.getContentPane().add(Dates, null);
        this.getContentPane().add(Aadhar, null);
        this.getContentPane().add(Name, null);
        this.getContentPane().add(roleID4, null);
        this.getContentPane().add(roleID3, null);
        this.getContentPane().add(roleID2, null);
        this.getContentPane().add(roleID1, null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }

    private void AddButton_actionPerformed(ActionEvent e) {
            String name = Name.getText();
            String aadhar = Aadhar.getText();
            String date = Dates.getText();
            String phoneStr = phone.getText();
            String genderStr = (String) gender.getSelectedItem();

            AdminOperationImpl adminOpImpl = new AdminOperationImpl();
            AdminEO adminEO = new AdminEO();
            List<RoleEO> roleEOList = adminOpImpl.findRoleByRoleName((String)newCombo.getSelectedItem());

            for (RoleEO role : roleEOList) {
                adminEO.setRoleID(role);
                adminEO.setName(name);
                adminEO.setAadhar(aadhar);
                adminEO.setPassword("adm123");
                adminEO.setSignup(0);
                // New attributes
                adminEO.setGender(genderStr);
                if (phoneStr != null && !phoneStr.trim().isEmpty()) {
                    try {
                        adminEO.setPhone(Long.parseLong(phoneStr.trim()));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Invalid phone number!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
                break;
            }

            if (!date.equals("")) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date utilDate = sdf.parse(date);
                    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                    adminEO.setHireDate(sqlDate);
                } catch (Exception es) {
                    es.printStackTrace();
                }
            } else {
                adminEO.setHireDate(null);
            }

            if(validate.isValidName(adminEO.getName()) && validate.isValidAadhaar(adminEO.getAadhar())){
                System.out.println(adminOpImpl.addAdmin(adminEO));

                if (adminOpImpl.findAdminByAadhar(adminEO.getAadhar()) != null) {
                    String adminDetails = "Name: " + adminEO.getName() + "\n" +
                        "Aadhar: " + adminEO.getAadhar() + "\n" +
                        "Phone: " + adminEO.getPhone() + "\n" +
                        "Gender: " + adminEO.getGender() + "\n" +
                        "Role ID: " + adminEO.getRoleID().getRoleID() + "\n" +
                        "Designation ID: " + adminEO.getDesignationID() + "\n" +
                        "Hire Date: " + adminEO.getHireDate();

                    JOptionPane.showMessageDialog(this,
                        "Admin added successfully!\t\t\n\n" + adminDetails,
                        "Success", JOptionPane.INFORMATION_MESSAGE); 
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to add admin. Please try again.",
                    "Warning", JOptionPane.WARNING_MESSAGE);
            }
            clearFields();
        }

        // Dummy clearFields method
        private void clearFields() {
            Name.setText("");
            Aadhar.setText("");
            Dates.setText("");
            phone.setText("");
            gender.setSelectedIndex(0);
            newCombo.setSelectedIndex(0);
        }


    private void newCombo_actionPerformed(ActionEvent e) {
    }
}


