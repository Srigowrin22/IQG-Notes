package com.iqgateway.spring_boot_demo_way_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoWay2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
