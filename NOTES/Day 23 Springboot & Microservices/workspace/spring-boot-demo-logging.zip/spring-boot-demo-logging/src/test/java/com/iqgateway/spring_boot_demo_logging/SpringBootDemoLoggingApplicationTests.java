package com.iqgateway.spring_boot_demo_logging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoLoggingApplicationTests {

	@Test
	void contextLoads() {
	}

}
