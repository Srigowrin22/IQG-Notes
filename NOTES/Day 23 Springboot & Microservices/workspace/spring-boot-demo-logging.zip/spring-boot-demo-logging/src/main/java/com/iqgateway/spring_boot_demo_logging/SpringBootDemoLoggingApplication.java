package com.iqgateway.spring_boot_demo_logging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemoLoggingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoLoggingApplication.class, args);
	}

}
